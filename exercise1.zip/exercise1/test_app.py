import unittest
import requests

class TestAPI(unittest.TestCase):
    URL = "http://127.0.0.1:5000/query"

    def test_sport_tag(self):
        response = requests.get(self.URL + '?sport=football&sortBy=&order=')
        self.assertEqual(response.status_code, 200)
        print("test sport_tag completed")
    
    def test_missing_sport_tag(self):
        response = requests.get(self.URL + '?sport=&sortBy=&order=')
        self.assertEqual(response.status_code, 400)
        self.assertEqual("sport invalid", response.json())
        print("test missing_sport_tag completed")

    def test_sortby_inexistent(self):
        response = requests.get(self.URL + '?sport=football&sortBy=foo&order=')
        self.assertEqual(response.status_code, 400)
        self.assertEqual("sortby invalid", response.json())
        print("test sortby_inexistent completed")

    def test_order_inexistent(self):
        response = requests.get(self.URL + '?sport=football&sortBy=&order=foo')
        self.assertEqual(response.status_code, 400)
        self.assertEqual("order invalid", response.json())
        print("test order_inexistent completed")

if __name__ == '__main__':
    unittest.main()
from flask import Flask, json, jsonify, make_response, render_template, request
import requests

app = Flask(__name__)

with open('./data.json') as file:
    data = json.load(file)

@app.route('/', methods=["GET"])
def home():
    return render_template("index.html")
@app.route('/query', methods=["GET"])
def get_users_by_sprts():
    sport = request.args.get("sport")
    sortby = request.args.get("sortBy")
    order = request.args.get("order")
    print(sport)
    if not sport:
        response = make_response(jsonify("sport is required"), 400)
    if not sortby:
        sortby = "lastName"
    if not order:
        order = "asc"
    print(sortby)
    if sport not in ["volley", "football", "basketball", "hockey", "tennis"]:
        response = make_response(jsonify("sport invalid"), 400)
    elif sortby not in ["firstName", "lastName", "emailAddress", "phoneNumber"]:
        response = make_response(jsonify("sortby invalid"), 400)
    elif order not in ["desc", "asc"]:
        response = make_response(jsonify("order invalid"), 400)
    else:
        result = {}
        result["users"] = []
        for user in data["users"]:
            if sport in user["sports"]:
                result["users"].append(user)
        if order == "asc":
            result["users"] = sorted(result["users"], key=lambda k:k[sortby])
        else:
            result["users"] = sorted(result["users"], key=lambda k:k[sortby], reverse=True)
        response = make_response(jsonify(result), 200)
    return response    